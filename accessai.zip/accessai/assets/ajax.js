function updateItem(email,username,contact,city,address){
	  document.getElementById('email').value=email;
	  document.getElementById('username').value=username;
	  document.getElementById('phno').value=contact;
	  document.getElementById('city').value=city;
	  document.getElementById('address').value=address;
	  return true;
}