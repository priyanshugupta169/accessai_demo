from django.contrib import admin
from .models import Accounts
# Register your models here.
admin.site.register(Accounts)